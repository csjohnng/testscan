if (window.console) {
	console.log('You are using the Highcharts Bower repo. This repo is for source and' +
	' utilities and not optimized for production. Instead, use the official shim repos ' + 
	' "highcharts-release", "highstock-release" or "highmaps-release".');
}