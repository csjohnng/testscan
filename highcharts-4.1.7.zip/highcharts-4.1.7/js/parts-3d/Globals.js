/**
	Shorthands for often used function
*/ 
